package com.kh.run;

import com.kh.view.ProductMenu;

public class Run {
	public static void main(String[] args) {
		new ProductMenu().mainMenu();

	}
}
